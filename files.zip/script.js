/* =====================================================
   TechNiv - SETTINGS (change these in ONE place)
   ===================================================== */
const WHATSAPP_NUMBER = "919315170420";   // country code + number, no + or spaces
const PHONE_NUMBER    = "+919315170420";  // for the Call Now button
const EMAIL           = "vishalkumar7532@gmail.com";
const BUSINESS        = "TechNiv";

/* =====================================================
   PRODUCTS - edit / add / remove products here.
   cat: "hdd" | "laptop" | "desktop" | "acc"
   price: number in rupees (0 = "Call for price")
   img: "images/yourfile.jpg" (leave "" to show an icon)
   health: number like 90 (only for HDD/SSD)
   NOTE: the prices below are SAMPLE prices - replace them.
   ===================================================== */
const PRODUCTS = [
  {id:1, cat:"hdd", name:"WD Blue 1TB HDD", brand:"WD", type:"Internal", capacity:"1TB", interface:"SATA", condition:"Used", health:90, tested:true, price:1500, available:true, warranty:"1 month", img:""},
  {id:2, cat:"hdd", name:"Seagate 500GB HDD", brand:"Seagate", type:"Internal", capacity:"500GB", interface:"SATA", condition:"Used", health:95, tested:true, price:800, available:true, warranty:"1 month", img:""},
  {id:3, cat:"hdd", name:"Toshiba 2TB External HDD", brand:"Toshiba", type:"External", capacity:"2TB", interface:"USB 3.0", condition:"Refurbished", health:90, tested:true, price:3200, available:true, warranty:"3 months", img:""},
  {id:4, cat:"hdd", name:"WD Elements 4TB External HDD", brand:"WD", type:"External", capacity:"4TB", interface:"USB 3.0", condition:"New", health:100, tested:true, price:7500, available:false, warranty:"1 year", img:""},
  {id:5, cat:"laptop", name:"Dell Latitude 5490", brand:"Dell", processor:"i5", ram:"8GB", storage:"256GB", condition:"Refurbished", tested:true, price:18500, available:true, warranty:"3 months", img:""},
  {id:6, cat:"laptop", name:"HP EliteBook 840 G5", brand:"HP", processor:"i7", ram:"16GB", storage:"512GB", condition:"Used", tested:true, price:24500, available:true, warranty:"1 month", img:""},
  {id:7, cat:"laptop", name:"Lenovo ThinkPad T470", brand:"Lenovo", processor:"i5", ram:"8GB", storage:"256GB", condition:"Used", tested:true, price:16500, available:true, warranty:"1 month", img:""},
  {id:8, cat:"laptop", name:"Acer Aspire 5 Ryzen 5", brand:"Acer", processor:"Ryzen 5", ram:"8GB", storage:"512GB", condition:"New", tested:true, price:38000, available:true, warranty:"1 year", img:""},
  {id:9, cat:"desktop", name:"Dell OptiPlex Office PC", brand:"Dell", processor:"Intel i5", ram:"8GB", storage:"SSD + HDD", usage:"Office", condition:"Refurbished", tested:true, price:14500, available:true, warranty:"3 months", img:""},
  {id:10, cat:"desktop", name:"Ryzen 5 Gaming PC", brand:"Custom", processor:"Ryzen", ram:"16GB", storage:"SSD", usage:"Gaming", condition:"New", tested:true, price:42000, available:true, warranty:"1 year", img:""},
  {id:11, cat:"desktop", name:"HP ProDesk Home PC", brand:"HP", processor:"Intel i3", ram:"4GB", storage:"HDD", usage:"Home", condition:"Used", tested:true, price:9500, available:true, warranty:"1 month", img:""},
  {id:12, cat:"acc", name:"8GB DDR4 Laptop RAM", brand:"Kingston", ram:"8GB", condition:"Used", tested:true, price:1200, available:true, warranty:"1 month", img:""},
  {id:13, cat:"acc", name:"SATA to USB 3.0 Adapter", brand:"Generic", condition:"New", tested:true, price:350, available:true, warranty:"", img:""}
];

/* =====================================================
   FILTERS - which dropdowns show for each category.
   k = product field, l = label, o = options
   ===================================================== */
const FILTERS = {
  hdd: [
    {k:"type", l:"Type", o:["Internal","External"]},
    {k:"capacity", l:"Capacity", o:["250GB","500GB","1TB","2TB","4TB"]},
    {k:"condition", l:"Condition", o:["Used","Refurbished","New"]},
    {k:"health", l:"Health", o:[80,90,95], min:true, fmt:v=>v+"%+"}
  ],
  laptop: [
    {k:"brand", l:"Brand", o:["Dell","HP","Lenovo","Acer","ASUS","Other"]},
    {k:"processor", l:"Processor", o:["i3","i5","i7","Ryzen 3","Ryzen 5","Ryzen 7"]},
    {k:"ram", l:"RAM", o:["4GB","8GB","16GB","32GB"]},
    {k:"storage", l:"Storage", o:["256GB","512GB","1TB"]},
    {k:"condition", l:"Condition", o:["Used","Refurbished","New"]}
  ],
  desktop: [
    {k:"processor", l:"Processor", o:["Intel i3","Intel i5","Intel i7","Ryzen"]},
    {k:"ram", l:"RAM", o:["4GB","8GB","16GB","32GB"]},
    {k:"storage", l:"Storage", o:["HDD","SSD","SSD + HDD"]},
    {k:"usage", l:"Usage", o:["Office","Home","Gaming","Business"]}
  ],
  acc: []
};
const TABS = [["all","All"],["hdd","HDD"],["laptop","Laptops"],["desktop","Desktops"],["acc","RAM & Accessories"]];
const ICONS = {hdd:"💽", laptop:"💻", desktop:"🖥️", acc:"🔌"};
const LABELS = {brand:"Brand", type:"Type", capacity:"Capacity", interface:"Interface", processor:"Processor", ram:"RAM", storage:"Storage", usage:"Usage", condition:"Condition", health:"Health"};

/* =====================================================
   CODE BELOW - you normally do not need to edit
   ===================================================== */
const $ = id => document.getElementById(id);
const state = {cat:"all", q:"", f:{}, sort:""};
let enquiry = [];   // [{id, qty}]

const rupees = n => n ? "₹" + n.toLocaleString("en-IN") : "Call for price";
const val = (k, v) => k === "health" ? v + "%+" : v;
const byId = id => PRODUCTS.find(p => p.id === id);

/* ---------- WhatsApp ---------- */
function openWA(text){
  window.open("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(text), "_blank");
}
function productLines(p){
  let t = "Product: " + p.name + "\n";
  ["capacity","processor","ram","storage","condition","health"].forEach(k => { if (p[k]) t += LABELS[k] + ": " + val(k, p[k]) + "\n"; });
  return t + "Price: " + rupees(p.price) + "\n";
}
function enquireOne(id){
  openWA("Hello " + BUSINESS + ",\n\nI am interested in this product:\n\n" + productLines(byId(id)) + "\nPlease provide availability and final price.\n\nThank you.");
}
function sendEnquiryList(){
  if (!enquiry.length) return;
  const list = enquiry.map(e => "- " + byId(e.id).name + " x " + e.qty + " (" + rupees(byId(e.id).price) + ")").join("\n");
  openWA("Hello " + BUSINESS + ",\n\nI am interested in these products:\n\n" + list + "\n\nPlease provide availability and final price.\n\nThank you.");
}

/* ---------- Product grid ---------- */
function visible(){
  const q = state.q.toLowerCase().trim();
  let list = PRODUCTS.filter(p => {
    if (state.cat !== "all" && p.cat !== state.cat) return false;
    if (q && !(Object.values(p).join(" ") + " " + p.cat).toLowerCase().includes(q)) return false;
    return (FILTERS[state.cat] || []).every(f => {
      const v = state.f[f.k];
      if (!v) return true;
      return f.min ? p[f.k] >= Number(v) : String(p[f.k]) === v;
    });
  });
  if (state.sort) list.sort((a, b) => state.sort === "low" ? a.price - b.price : b.price - a.price);
  return list;
}
function card(p){
  const specs = ["capacity","processor","ram","storage","type"].filter(k => p[k]).map(k => p[k]).join(" • ");
  return `<article class="card">
    <div class="thumb">${p.img ? `<img src="${p.img}" alt="${p.name}" loading="lazy">` : ICONS[p.cat]}</div>
    <div class="body">
      <h3>${p.name}</h3>
      <div class="specs">${p.brand}${specs ? " • " + specs : ""}</div>
      <div><span class="tag">${p.condition}</span>${p.health ? `<span class="tag">Health ${p.health}%+</span>` : ""}<span class="tag ${p.available ? "ok" : "no"}">${p.available ? "Available" : "Out of stock"}</span></div>
      <div class="price">${rupees(p.price)}</div>
      <div class="btns">
        <button class="btn ghost" data-act="view" data-id="${p.id}">View Details</button>
        <button class="btn wa" data-act="enq" data-id="${p.id}">WhatsApp Enquiry</button>
        <button class="btn ghost full" data-act="add" data-id="${p.id}">+ Add to My Enquiry</button>
      </div></div></article>`;
}
function render(){
  const list = visible();
  $("grid").innerHTML = list.map(card).join("") || "<p>No products found. Try different filters.</p>";
  $("count").textContent = list.length + " product(s)";
  $("tabs").innerHTML = TABS.map(t => `<button class="tab ${state.cat === t[0] ? "on" : ""}" data-tab="${t[0]}">${t[1]}</button>`).join("");
}
function renderFilters(){
  const fs = FILTERS[state.cat] || [];
  let html = fs.map(f => `<label>${f.l}<select class="input" data-f="${f.k}"><option value="">All</option>${f.o.map(o => `<option value="${o}" ${String(state.f[f.k]) === String(o) ? "selected" : ""}>${f.fmt ? f.fmt(o) : o}</option>`).join("")}</select></label>`).join("");
  html += `<label>Sort by price<select class="input" id="sort"><option value="">Default</option><option value="low" ${state.sort === "low" ? "selected" : ""}>Low to High</option><option value="high" ${state.sort === "high" ? "selected" : ""}>High to Low</option></select></label>`;
  $("filters").innerHTML = html;
}
function setCat(c){ state.cat = c; state.f = {}; renderFilters(); render(); }

/* ---------- Details modal ---------- */
function showDetails(id){
  const p = byId(id);
  const rows = Object.keys(LABELS).filter(k => p[k]).map(k => `<tr><td>${LABELS[k]}</td><td>${val(k, p[k])}</td></tr>`).join("");
  $("modalBody").innerHTML = `<button class="btn ghost close" data-act="close">Close</button>
    <div class="thumb">${p.img ? `<img src="${p.img}" alt="${p.name}">` : ICONS[p.cat]}</div>
    <h3>${p.name}</h3><div class="price">${rupees(p.price)}</div>
    <table>${rows}<tr><td>Testing</td><td>${p.tested ? "Tested" : "Not tested"}</td></tr>
    <tr><td>Warranty</td><td>${p.warranty || "No warranty"}</td></tr>
    <tr><td>Availability</td><td>${p.available ? "Available" : "Out of stock"}</td></tr></table>
    <div class="btns"><button class="btn wa" data-act="enq" data-id="${p.id}">Buy / Enquire on WhatsApp</button>
    <button class="btn ghost" data-act="add" data-id="${p.id}">+ Add to My Enquiry</button></div>`;
  $("modal").hidden = false;
}

/* ---------- My Enquiry list ---------- */
function addToEnquiry(id){
  const e = enquiry.find(x => x.id === id);
  e ? e.qty++ : enquiry.push({id, qty:1});
  updateCount();
}
function updateCount(){ $("enqCount").textContent = enquiry.reduce((s, e) => s + e.qty, 0); }
function showDrawer(){
  const items = enquiry.map(e => `<div class="item"><span>${byId(e.id).name}</span>
    <span class="qty"><button data-act="dec" data-id="${e.id}">−</button> ${e.qty} <button data-act="inc" data-id="${e.id}">+</button></span></div>`).join("");
  $("drawerBody").innerHTML = `<button class="btn ghost close" data-act="close">Close</button><h3>My Enquiry</h3>` +
    (items || "<p class='muted'>Nothing added yet. Use “Add to My Enquiry” on any product.</p>") +
    (enquiry.length ? `<button class="btn wa full" style="width:100%;margin-top:14px" data-act="send">Send Enquiry on WhatsApp</button>` : "");
  $("drawer").hidden = false;
}

/* ---------- Events ---------- */
document.addEventListener("click", e => {
  const t = e.target.closest("[data-act],[data-tab],[data-cat],[data-wa]");
  if (e.target.classList.contains("overlay")) e.target.hidden = true;
  if (!t) return;
  const id = Number(t.dataset.id);
  if (t.dataset.tab) setCat(t.dataset.tab);
  else if (t.dataset.cat) { setCat(t.dataset.cat); $("nav").classList.remove("open"); }
  else if (t.dataset.wa) { e.preventDefault(); openWA("Hello " + BUSINESS + ", I would like to know more about your products."); }
  else switch (t.dataset.act) {
    case "view": showDetails(id); break;
    case "enq": enquireOne(id); break;
    case "add": addToEnquiry(id); t.textContent = "Added ✓"; break;
    case "close": $("modal").hidden = $("drawer").hidden = true; break;
    case "send": sendEnquiryList(); break;
    case "inc": enquiry.find(x => x.id === id).qty++; updateCount(); showDrawer(); break;
    case "dec": { const x = enquiry.find(x => x.id === id); if (--x.qty <= 0) enquiry = enquiry.filter(y => y !== x); updateCount(); showDrawer(); }
  }
});
document.addEventListener("change", e => {
  if (e.target.dataset.f !== undefined) { state.f[e.target.dataset.f] = e.target.value; render(); }
  if (e.target.id === "sort") { state.sort = e.target.value; render(); }
});
$("search").addEventListener("input", e => { state.q = e.target.value; render(); });
$("burger").addEventListener("click", () => $("nav").classList.toggle("open"));
$("enqBtn").addEventListener("click", showDrawer);
document.addEventListener("keydown", e => { if (e.key === "Escape") $("modal").hidden = $("drawer").hidden = true; });

/* Enquiry form -> WhatsApp */
$("form").addEventListener("submit", e => {
  e.preventDefault();
  const d = new FormData(e.target);
  openWA("Hello " + BUSINESS + ",\n\nName: " + d.get("name") + "\nMobile: " + d.get("mobile") + "\nProduct: " + d.get("product") + "\nQuantity: " + d.get("qty") + (d.get("msg") ? "\nMessage: " + d.get("msg") : "") + "\n\nI want to know the availability and final price.\n\nThank you.");
});

/* Contact links */
$("callBtn").href = "tel:" + PHONE_NUMBER;
$("footPhone").href = "tel:" + PHONE_NUMBER; $("footPhone").textContent = PHONE_NUMBER;
$("footMail").href = "mailto:" + EMAIL; $("footMail").textContent = EMAIL;

renderFilters(); render();
